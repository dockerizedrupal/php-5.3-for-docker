This directory holds the build script for Drush's Windows distribution. This script is only useful to Drush administrators who are generating a new build. 

To use this script:

- Edit the metadata at the top
- Run the script
- Attach the .zip file to the correspionding Release on Github.
- Update the links at bottom of docs/install.md
